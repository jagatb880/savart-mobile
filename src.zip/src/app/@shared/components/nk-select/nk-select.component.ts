import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nk-select',
  templateUrl: './nk-select.component.html',
  styleUrls: ['./nk-select.component.scss'],
})
export class NkSelectComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
