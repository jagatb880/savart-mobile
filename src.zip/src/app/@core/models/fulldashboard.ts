export const fullDasborad = {
  data: [
    [
      {
        goalid: 2,
        goalname: "Own a Home",
        goalicon1: "Goal/icons/Own a Home.svg",
        goalicon2: "",
        goaltargetamt: "992999.00",
        goal_invested_amount: "82192.35",
        goal_invested_current_amount: "80075.25",
        gain_amount_ongoal: "-2117.10",
        gain_percent_ongoal: "-2.58",
        goalprogress: 8.06398093049439,
      },
    ],
  ],
};
