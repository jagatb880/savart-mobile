import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { IonicModule } from "@ionic/angular";

import { InboxPageRoutingModule } from "./inbox-routing.module";

import { InboxPage } from "./inbox.page";
import { SharedModule } from "@shared/shared.module";

@NgModule({
  imports: [CommonModule, FormsModule, IonicModule, InboxPageRoutingModule, ReactiveFormsModule, SharedModule],
  declarations: [InboxPage],
})
export class InboxPageModule {}
