export const environment = {
  production: true,
  domain: `https://savart.in`,
  RAZORPAY_API_KEY: "rzp_test_tA5haXDJopDQY9",
  RAZORPAY_API_SECRET_KEY: "gWbEVNfF6y3FMnJLSpvHihiN",
  firebaseConfig: {
    apiKey: "AIzaSyCQ70KmRbu33bncD6Jaqo2WzZWMxz_rJuY",
    authDomain: "savart-mob.firebaseapp.com",
    databaseURL: "https://savart-mob.firebaseio.com",
    projectId: "savart-mob",
    storageBucket: "savart-mob.appspot.com",
    messagingSenderId: "266048666059",
    appId: "1:266048666059:web:b2293dc8847617e36b9e4e",
    measurementId: "G-8MQL7BR076",
  },
};
